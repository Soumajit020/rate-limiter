package com.example.ratelimiter.service;

import com.example.ratelimiter.config.RateLimiterProperties;
import com.example.ratelimiter.security.ClientPrincipal;
import org.junit.jupiter.api.Test;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.mock.web.MockHttpServletRequest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

class FraudAbuseServiceTest {

    /**
     * Verifies that clients listed in the blocked-client policy are denied.
     */
    @Test
    void deniesBlockedClient() {
        RateLimiterProperties properties = properties();
        properties.getAbuse().setBlockedClients(List.of("bad-client"));
        FraudAbuseService service = new FraudAbuseService(properties, mock(StringRedisTemplate.class));

        var decision = service.inspectRequest(principal("bad-client"), new MockHttpServletRequest());

        assertThat(decision.allowed()).isFalse();
        assertThat(decision.reason()).isEqualTo("CLIENT_BLOCKED");
    }

    /**
     * Verifies that a request above the configured risk score is denied.
     */
    @Test
    void deniesHighRiskRequest() {
        FraudAbuseService service = new FraudAbuseService(properties(), mock(StringRedisTemplate.class));
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("X-Risk-Score", "95");

        var decision = service.inspectRequest(principal("demo-search"), request);

        assertThat(decision.allowed()).isFalse();
        assertThat(decision.reason()).isEqualTo("HIGH_RISK_REQUEST");
    }

    /**
     * Verifies that known scanner User-Agent markers are denied.
     */
    @Test
    void deniesSuspiciousUserAgent() {
        RateLimiterProperties properties = properties();
        properties.getAbuse().setSuspiciousUserAgents(List.of("sqlmap"));
        FraudAbuseService service = new FraudAbuseService(properties, mock(StringRedisTemplate.class));
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("User-Agent", "sqlmap/1.7");

        var decision = service.inspectRequest(principal("demo-search"), request);

        assertThat(decision.allowed()).isFalse();
        assertThat(decision.reason()).isEqualTo("SUSPICIOUS_USER_AGENT");
    }

    /**
     * Builds minimal fraud and abuse properties used by these tests.
     */
    private RateLimiterProperties properties() {
        RateLimiterProperties properties = new RateLimiterProperties();
        properties.getAbuse().setMaxRiskScore(80);
        return properties;
    }

    /**
     * Creates an authenticated client principal with the SEARCH role.
     */
    private ClientPrincipal principal(String clientId) {
        return new ClientPrincipal(clientId, List.of("SEARCH"), new RateLimiterProperties.Policy());
    }
}
