$ErrorActionPreference = "Stop"

$rootPassword = if ($env:MYSQL_ROOT_PASSWORD) { $env:MYSQL_ROOT_PASSWORD } else { throw "Set MYSQL_ROOT_PASSWORD before running this script." }
$mysqlUser = if ($env:MYSQL_USERNAME) { $env:MYSQL_USERNAME } else { "rate_limiter" }
$mysqlPassword = if ($env:MYSQL_PASSWORD) { $env:MYSQL_PASSWORD } else { throw "Set MYSQL_PASSWORD before running this script." }

docker exec rate-limiter-mysql mysql `
  -uroot `
  "-p$rootPassword" `
  -e "DROP DATABASE IF EXISTS rate_limiter_db; CREATE DATABASE rate_limiter_db; GRANT ALL PRIVILEGES ON rate_limiter_db.* TO '$mysqlUser'@'%' IDENTIFIED BY '$mysqlPassword'; FLUSH PRIVILEGES;"
