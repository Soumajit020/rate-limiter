package com.example.ratelimiter.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Validated
@ConfigurationProperties(prefix = "rate-limiter")
public class RateLimiterProperties {

    @Valid
    @NotNull
    private Policy defaultPolicy = new Policy();

    @Valid
    @NotEmpty
    private Map<String, Client> clients = new HashMap<>();

    @Valid
    @NotNull
    private Abuse abuse = new Abuse();

    /**
     * Returns the fallback rate-limit policy used when a client has no custom policy.
     */
    public Policy getDefaultPolicy() {
        return defaultPolicy;
    }

    /**
     * Sets the fallback rate-limit policy used when a client has no custom policy.
     */
    public void setDefaultPolicy(Policy defaultPolicy) {
        this.defaultPolicy = defaultPolicy;
    }

    /**
     * Returns all configured API clients keyed by client id.
     */
    public Map<String, Client> getClients() {
        return clients;
    }

    /**
     * Sets all configured API clients keyed by client id.
     */
    public void setClients(Map<String, Client> clients) {
        this.clients = clients;
    }

    /**
     * Returns the fraud and abuse policy used by the request filter.
     */
    public Abuse getAbuse() {
        return abuse;
    }

    /**
     * Sets the fraud and abuse policy used by the request filter.
     */
    public void setAbuse(Abuse abuse) {
        this.abuse = abuse;
    }

    public static class Client {
        @NotBlank
        private String apiKey;

        @NotEmpty
        private List<String> roles = new ArrayList<>();

        @Valid
        private Policy policy;

        /**
         * Returns the API key expected for this client.
         */
        public String getApiKey() {
            return apiKey;
        }

        /**
         * Sets the API key expected for this client.
         */
        public void setApiKey(String apiKey) {
            this.apiKey = apiKey;
        }

        /**
         * Returns the security roles granted to this client.
         */
        public List<String> getRoles() {
            return roles;
        }

        /**
         * Sets the security roles granted to this client.
         */
        public void setRoles(List<String> roles) {
            this.roles = roles;
        }

        /**
         * Returns the custom rate-limit policy for this client, when configured.
         */
        public Policy getPolicy() {
            return policy;
        }

        /**
         * Sets the custom rate-limit policy for this client.
         */
        public void setPolicy(Policy policy) {
            this.policy = policy;
        }
    }

    public static class Policy {
        @Min(1)
        private long capacity = 60;

        @Min(1)
        private long refillTokens = 60;

        @NotNull
        private Duration refillPeriod = Duration.ofMinutes(1);

        /**
         * Returns the maximum number of tokens the bucket can hold.
         */
        public long getCapacity() {
            return capacity;
        }

        /**
         * Sets the maximum number of tokens the bucket can hold.
         */
        public void setCapacity(long capacity) {
            this.capacity = capacity;
        }

        /**
         * Returns how many tokens are added during each refill period.
         */
        public long getRefillTokens() {
            return refillTokens;
        }

        /**
         * Sets how many tokens are added during each refill period.
         */
        public void setRefillTokens(long refillTokens) {
            this.refillTokens = refillTokens;
        }

        /**
         * Returns how often tokens are added back to the bucket.
         */
        public Duration getRefillPeriod() {
            return refillPeriod;
        }

        /**
         * Sets how often tokens are added back to the bucket.
         */
        public void setRefillPeriod(Duration refillPeriod) {
            this.refillPeriod = refillPeriod;
        }
    }

    public static class Abuse {
        @Min(0)
        private int maxRiskScore = 80;

        private List<String> blockedClients = new ArrayList<>();
        private List<String> blockedIps = new ArrayList<>();
        private List<String> suspiciousUserAgents = new ArrayList<>();

        @Min(1)
        private long failedAuthThreshold = 5;

        @NotNull
        private Duration failedAuthWindow = Duration.ofMinutes(10);

        /**
         * Returns the highest accepted upstream risk score.
         */
        public int getMaxRiskScore() {
            return maxRiskScore;
        }

        /**
         * Sets the highest accepted upstream risk score.
         */
        public void setMaxRiskScore(int maxRiskScore) {
            this.maxRiskScore = maxRiskScore;
        }

        /**
         * Returns client ids that are always blocked.
         */
        public List<String> getBlockedClients() {
            return blockedClients;
        }

        /**
         * Sets client ids that are always blocked.
         */
        public void setBlockedClients(List<String> blockedClients) {
            this.blockedClients = blockedClients;
        }

        /**
         * Returns IP addresses that are always blocked.
         */
        public List<String> getBlockedIps() {
            return blockedIps;
        }

        /**
         * Sets IP addresses that are always blocked.
         */
        public void setBlockedIps(List<String> blockedIps) {
            this.blockedIps = blockedIps;
        }

        /**
         * Returns User-Agent markers that indicate suspicious automation.
         */
        public List<String> getSuspiciousUserAgents() {
            return suspiciousUserAgents;
        }

        /**
         * Sets User-Agent markers that indicate suspicious automation.
         */
        public void setSuspiciousUserAgents(List<String> suspiciousUserAgents) {
            this.suspiciousUserAgents = suspiciousUserAgents;
        }

        /**
         * Returns how many failed authorizations are allowed within the tracking window.
         */
        public long getFailedAuthThreshold() {
            return failedAuthThreshold;
        }

        /**
         * Sets how many failed authorizations are allowed within the tracking window.
         */
        public void setFailedAuthThreshold(long failedAuthThreshold) {
            this.failedAuthThreshold = failedAuthThreshold;
        }

        /**
         * Returns how long failed authorization attempts stay in Redis.
         */
        public Duration getFailedAuthWindow() {
            return failedAuthWindow;
        }

        /**
         * Sets how long failed authorization attempts stay in Redis.
         */
        public void setFailedAuthWindow(Duration failedAuthWindow) {
            this.failedAuthWindow = failedAuthWindow;
        }
    }
}
