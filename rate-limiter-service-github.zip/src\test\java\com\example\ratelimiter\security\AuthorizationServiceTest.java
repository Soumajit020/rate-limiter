package com.example.ratelimiter.security;

import com.example.ratelimiter.config.RateLimiterProperties;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class AuthorizationServiceTest {

    /**
     * Verifies that a configured client id and API key produce an authenticated principal.
     */
    @Test
    void authenticatesConfiguredClient() {
        AuthorizationService service = new AuthorizationService(properties());

        var principal = service.authenticate("demo-search", "demo-search-key");

        assertThat(principal).isPresent();
        assertThat(principal.get().clientId()).isEqualTo("demo-search");
        assertThat(principal.get().roles()).containsExactly("SEARCH");
    }

    /**
     * Verifies that an invalid API key is rejected.
     */
    @Test
    void rejectsWrongApiKey() {
        AuthorizationService service = new AuthorizationService(properties());

        assertThat(service.authenticate("demo-search", "wrong")).isEmpty();
    }

    /**
     * Builds minimal rate limiter properties used by these authorization tests.
     */
    private RateLimiterProperties properties() {
        RateLimiterProperties properties = new RateLimiterProperties();
        RateLimiterProperties.Client client = new RateLimiterProperties.Client();
        client.setApiKey("demo-search-key");
        client.setRoles(List.of("SEARCH"));
        properties.setClients(Map.of("demo-search", client));
        return properties;
    }
}
