package com.example.ratelimiter.dto;

public record SearchResponse(
        boolean found,
        String query,
        String result,
        String source
) {

    /**
     * Creates a response for a query that was not found in Redis or MySQL.
     */
    public static SearchResponse miss(String query) {
        return new SearchResponse(false, query, null, "MISS");
    }
}
