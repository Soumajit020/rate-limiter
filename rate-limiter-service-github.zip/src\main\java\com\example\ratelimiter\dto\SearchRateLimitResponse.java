package com.example.ratelimiter.dto;

public record SearchRateLimitResponse(
        boolean allowed,
        String reason,
        long remainingTokens,
        long retryAfterSeconds
) {

    /**
     * Converts the internal rate-limit decision into the API response shape.
     */
    public static SearchRateLimitResponse from(RateLimitDecision decision) {
        return new SearchRateLimitResponse(
                decision.allowed(),
                decision.reason(),
                decision.remainingTokens(),
                decision.retryAfterSeconds());
    }
}
