package com.example.ratelimiter.service;

import com.example.ratelimiter.dto.SearchResponse;
import com.example.ratelimiter.entity.SearchDocument;
import com.example.ratelimiter.repository.SearchDocumentRepository;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class SearchServiceTest {

    private final SearchCacheService cacheService = mock(SearchCacheService.class);
    private final SearchDocumentRepository repository = mock(SearchDocumentRepository.class);
    private final SearchService searchService = new SearchService(cacheService, repository);

    /**
     * Verifies that Redis cache hits are returned without querying MySQL.
     */
    @Test
    void returnsCachedResultBeforeMysqlLookup() {
        when(cacheService.get("laptop")).thenReturn(Optional.of(new SearchResponse(true, "laptop", "cached", "MYSQL")));

        SearchResponse response = searchService.search("laptop");

        assertThat(response.source()).isEqualTo("CACHE");
        assertThat(response.result()).isEqualTo("cached");
        verify(repository, never()).findFirstByQueryTextIgnoreCase("laptop");
    }

    /**
     * Verifies that MySQL results are returned and cached when Redis misses.
     */
    @Test
    void fallsBackToMysqlAndCachesResult() {
        SearchDocument document = new SearchDocument();
        document.setQueryText("laptop");
        document.setResultPayload("mysql");
        when(cacheService.get("laptop")).thenReturn(Optional.empty());
        when(repository.findFirstByQueryTextIgnoreCase("laptop")).thenReturn(Optional.of(document));

        SearchResponse response = searchService.search("laptop");

        assertThat(response.source()).isEqualTo("MYSQL");
        assertThat(response.result()).isEqualTo("mysql");
        verify(cacheService).put("laptop", response);
    }
}
