docker stop rate-limiter-redis rate-limiter-mysql
docker rm rate-limiter-redis rate-limiter-mysql
