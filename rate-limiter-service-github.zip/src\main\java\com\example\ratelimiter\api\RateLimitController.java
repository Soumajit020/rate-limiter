package com.example.ratelimiter.api;

import com.example.ratelimiter.dto.SearchRateLimitRequest;
import com.example.ratelimiter.dto.SearchRateLimitResponse;
import com.example.ratelimiter.security.ClientPrincipal;
import com.example.ratelimiter.service.RateLimiterService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/rate-limit")
public class RateLimitController {

    private final RateLimiterService rateLimiterService;

    /**
     * Wires the Redis-backed rate limiter into this API controller.
     */
    public RateLimitController(RateLimiterService rateLimiterService) {
        this.rateLimiterService = rateLimiterService;
    }

    /**
     * Checks whether an authenticated client can perform a search request.
     */
    @PostMapping("/search/check")
    @PreAuthorize("hasRole('SEARCH')")
    public ResponseEntity<SearchRateLimitResponse> checkSearch(
            @AuthenticationPrincipal ClientPrincipal principal,
            @Valid @RequestBody SearchRateLimitRequest request) {
        String resource = request.userId() == null || request.userId().isBlank()
                ? "search:anonymous"
                : "search:user:" + request.userId();

        var decision = rateLimiterService.consume(principal.clientId(), resource, principal.policy());
        var response = SearchRateLimitResponse.from(decision);

        if (decision.allowed()) {
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.status(429)
                .header("Retry-After", String.valueOf(decision.retryAfterSeconds()))
                .body(response);
    }
}
