package com.example.ratelimiter.repository;

import com.example.ratelimiter.entity.SearchDocument;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SearchDocumentRepository extends JpaRepository<SearchDocument, Long> {

    /**
     * Finds the first MySQL search document matching the query, ignoring letter case.
     */
    Optional<SearchDocument> findFirstByQueryTextIgnoreCase(String queryText);
}
