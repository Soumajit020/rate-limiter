$ErrorActionPreference = "Stop"

$mysqlDatabase = if ($env:MYSQL_DATABASE) { $env:MYSQL_DATABASE } else { "rate_limiter_db" }
$mysqlRootPassword = if ($env:MYSQL_ROOT_PASSWORD) { $env:MYSQL_ROOT_PASSWORD } else { throw "Set MYSQL_ROOT_PASSWORD before running this script." }
$mysqlUser = if ($env:MYSQL_USERNAME) { $env:MYSQL_USERNAME } else { "rate_limiter" }
$mysqlPassword = if ($env:MYSQL_PASSWORD) { $env:MYSQL_PASSWORD } else { throw "Set MYSQL_PASSWORD before running this script." }

docker network create rate-limiter-net 2>$null

docker run -d `
  --name rate-limiter-redis `
  --network rate-limiter-net `
  -p 6379:6379 `
  -v rate-limiter-redis-data:/data `
  redis:7.4-alpine `
  redis-server --appendonly yes

docker run -d `
  --name rate-limiter-mysql `
  --network rate-limiter-net `
  -p 3306:3306 `
  -e "MYSQL_DATABASE=$mysqlDatabase" `
  -e "MYSQL_ROOT_PASSWORD=$mysqlRootPassword" `
  -e "MYSQL_USER=$mysqlUser" `
  -e "MYSQL_PASSWORD=$mysqlPassword" `
  -v rate-limiter-mysql-data:/var/lib/mysql `
  mysql:8.4
