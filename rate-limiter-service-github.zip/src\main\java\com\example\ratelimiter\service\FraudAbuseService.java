package com.example.ratelimiter.service;

import com.example.ratelimiter.config.RateLimiterProperties;
import com.example.ratelimiter.dto.RateLimitDecision;
import com.example.ratelimiter.security.ClientPrincipal;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class FraudAbuseService {

    private static final String FAILED_AUTH_PREFIX = "abuse:failed-auth:";

    private final RateLimiterProperties properties;
    private final StringRedisTemplate redisTemplate;

    /**
     * Wires abuse policy configuration and Redis counters used for failed authorization tracking.
     */
    public FraudAbuseService(RateLimiterProperties properties, StringRedisTemplate redisTemplate) {
        this.properties = properties;
        this.redisTemplate = redisTemplate;
    }

    /**
     * Evaluates the request against configured fraud and abuse rules before the API continues.
     */
    public RateLimitDecision inspectRequest(ClientPrincipal principal, HttpServletRequest request) {
        var abuse = properties.getAbuse();
        String ip = clientIp(request);

        if (containsIgnoreCase(abuse.getBlockedClients(), principal.clientId())) {
            return RateLimitDecision.denied("CLIENT_BLOCKED", 0);
        }
        if (containsIgnoreCase(abuse.getBlockedIps(), ip)) {
            return RateLimitDecision.denied("IP_BLOCKED", 0);
        }
        if (hasSuspiciousUserAgent(request.getHeader("User-Agent"), abuse.getSuspiciousUserAgents())) {
            return RateLimitDecision.denied("SUSPICIOUS_USER_AGENT", 0);
        }
        if (riskScore(request) > abuse.getMaxRiskScore()) {
            return RateLimitDecision.denied("HIGH_RISK_REQUEST", 0);
        }
        if (tooManyFailedAuthorizations(principal.clientId(), ip, abuse.getFailedAuthThreshold())) {
            return RateLimitDecision.denied("AUTH_FAILURE_ABUSE", 0);
        }

        return RateLimitDecision.allowed(0);
    }

    /**
     * Stores a failed authorization attempt for both the client id and the caller IP.
     */
    public void recordFailedAuthorization(String clientId, String ip) {
        Duration window = properties.getAbuse().getFailedAuthWindow();
        incrementFailure("client:" + nullSafe(clientId), window);
        incrementFailure("ip:" + nullSafe(ip), window);
    }

    /**
     * Increments a Redis failure counter and sets its expiry when the counter is first created.
     */
    private void incrementFailure(String discriminator, Duration window) {
        String key = FAILED_AUTH_PREFIX + discriminator;
        Long count = redisTemplate.opsForValue().increment(key);
        if (count != null && count == 1) {
            redisTemplate.expire(key, window);
        }
    }

    /**
     * Checks whether either the client or IP has crossed the configured failed-auth threshold.
     */
    private boolean tooManyFailedAuthorizations(String clientId, String ip, long threshold) {
        return failureCount("client:" + nullSafe(clientId)) >= threshold
                || failureCount("ip:" + nullSafe(ip)) >= threshold;
    }

    /**
     * Reads a Redis failure counter and safely treats missing or invalid values as zero.
     */
    private long failureCount(String discriminator) {
        String value = redisTemplate.opsForValue().get(FAILED_AUTH_PREFIX + discriminator);
        if (value == null) {
            return 0;
        }
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    /**
     * Detects known scanner or attack-tool markers inside the User-Agent header.
     */
    private boolean hasSuspiciousUserAgent(String userAgent, Iterable<String> suspiciousAgents) {
        if (userAgent == null || userAgent.isBlank()) {
            return false;
        }
        String normalized = userAgent.toLowerCase(Locale.ROOT);
        Set<String> markers = toLowercaseSet(suspiciousAgents);
        return markers.stream().anyMatch(normalized::contains);
    }

    /**
     * Normalizes configured string values to lowercase for case-insensitive comparison.
     */
    private Set<String> toLowercaseSet(Iterable<String> values) {
        return ((java.util.Collection<String>) values).stream()
                .map(value -> value.toLowerCase(Locale.ROOT))
                .collect(Collectors.toSet());
    }

    /**
     * Reads the upstream risk score header and returns zero when it is absent or invalid.
     */
    private int riskScore(HttpServletRequest request) {
        String value = request.getHeader("X-Risk-Score");
        if (value == null || value.isBlank()) {
            return 0;
        }
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    /**
     * Checks whether a configured list contains a value without caring about letter case.
     */
    private boolean containsIgnoreCase(Iterable<String> values, String candidate) {
        if (candidate == null) {
            return false;
        }
        for (String value : values) {
            if (candidate.equalsIgnoreCase(value)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Resolves the caller IP, preferring X-Forwarded-For when the service is behind a proxy.
     */
    private String clientIp(HttpServletRequest request) {
        String forwardedFor = request.getHeader("X-Forwarded-For");
        if (forwardedFor != null && !forwardedFor.isBlank()) {
            return forwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }

    /**
     * Converts blank values to a stable Redis discriminator.
     */
    private String nullSafe(String value) {
        return value == null || value.isBlank() ? "unknown" : value;
    }
}
