package com.example.ratelimiter.service;

import com.example.ratelimiter.config.SearchCacheProperties;
import com.example.ratelimiter.dto.SearchResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SearchCacheService {

    private static final String SEARCH_CACHE_PREFIX = "search:cache:";

    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;
    private final SearchCacheProperties properties;

    /**
     * Wires Redis, JSON serialization, and cache TTL settings for search result caching.
     */
    public SearchCacheService(StringRedisTemplate redisTemplate, ObjectMapper objectMapper, SearchCacheProperties properties) {
        this.redisTemplate = redisTemplate;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    /**
     * Reads a search result from Redis and returns empty when the value is missing or invalid.
     */
    public Optional<SearchResponse> get(String query) {
        String cached = redisTemplate.opsForValue().get(cacheKey(query));
        if (cached == null) {
            return Optional.empty();
        }
        try {
            return Optional.of(objectMapper.readValue(cached, SearchResponse.class));
        } catch (JsonProcessingException ignored) {
            return Optional.empty();
        }
    }

    /**
     * Stores a search result in Redis so future requests can avoid a MySQL lookup.
     */
    public void put(String query, SearchResponse response) {
        try {
            redisTemplate.opsForValue().set(cacheKey(query), objectMapper.writeValueAsString(response), properties.getTtl());
        } catch (JsonProcessingException ignored) {
            // Cache write failure should not stop a successful MySQL lookup.
        }
    }

    /**
     * Builds the normalized Redis key used for a search query.
     */
    private String cacheKey(String query) {
        return SEARCH_CACHE_PREFIX + query.trim().toLowerCase();
    }
}
