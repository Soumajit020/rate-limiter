package com.example.ratelimiter.security;

import com.example.ratelimiter.config.RateLimiterProperties;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.security.MessageDigest;
import java.util.Optional;

@Service
public class AuthorizationService {

    private final RateLimiterProperties properties;

    /**
     * Wires configured clients and policies used for API-key authentication.
     */
    public AuthorizationService(RateLimiterProperties properties) {
        this.properties = properties;
    }

    /**
     * Validates the client id and API key and returns the authenticated client principal.
     */
    public Optional<ClientPrincipal> authenticate(String clientId, String apiKey) {
        if (!StringUtils.hasText(clientId) || !StringUtils.hasText(apiKey)) {
            return Optional.empty();
        }

        RateLimiterProperties.Client client = properties.getClients().get(clientId);
        if (client == null || !MessageDigest.isEqual(apiKey.getBytes(), client.getApiKey().getBytes())) {
            return Optional.empty();
        }

        RateLimiterProperties.Policy policy = client.getPolicy() == null
                ? properties.getDefaultPolicy()
                : client.getPolicy();

        return Optional.of(new ClientPrincipal(clientId, client.getRoles(), policy));
    }
}
