package com.example.ratelimiter.service;

import com.example.ratelimiter.config.RateLimiterProperties;
import com.example.ratelimiter.dto.RateLimitDecision;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.util.List;

@Service
public class RateLimiterService {

    private static final String RATE_LIMIT_PREFIX = "rate-limit:";

    private static final String TOKEN_BUCKET_SCRIPT = """
            local tokens_key = KEYS[1]
            local timestamp_key = KEYS[2]
            local capacity = tonumber(ARGV[1])
            local refill_tokens = tonumber(ARGV[2])
            local refill_period_ms = tonumber(ARGV[3])
            local requested = tonumber(ARGV[4])
            local now = tonumber(ARGV[5])

            local tokens = tonumber(redis.call('get', tokens_key))
            if tokens == nil then
              tokens = capacity
            end

            local last_refill = tonumber(redis.call('get', timestamp_key))
            if last_refill == nil then
              last_refill = now
            end

            local elapsed = math.max(0, now - last_refill)
            local refill = math.floor(elapsed / refill_period_ms) * refill_tokens
            local filled = math.min(capacity, tokens + refill)
            if refill > 0 then
              last_refill = now
            end

            local allowed = 0
            if filled >= requested then
              allowed = 1
              filled = filled - requested
            end

            local ttl = math.ceil((capacity / refill_tokens) * refill_period_ms)
            redis.call('set', tokens_key, filled, 'PX', ttl)
            redis.call('set', timestamp_key, last_refill, 'PX', ttl)

            local retry_after = 0
            if allowed == 0 then
              retry_after = math.ceil(refill_period_ms / 1000)
            end

            return { allowed, filled, retry_after }
            """;

    private final StringRedisTemplate redisTemplate;
    private final Clock clock;

    /**
     * Wires Redis access and uses the system UTC clock for production rate-limit decisions.
     */
    @Autowired
    public RateLimiterService(StringRedisTemplate redisTemplate) {
        this(redisTemplate, Clock.systemUTC());
    }

    /**
     * Allows tests to provide a fixed clock while reusing the same limiter logic.
     */
    RateLimiterService(StringRedisTemplate redisTemplate, Clock clock) {
        this.redisTemplate = redisTemplate;
        this.clock = clock;
    }

    /**
     * Consumes one token from the Redis token bucket for the given client and resource.
     */
    public RateLimitDecision consume(String clientId, String resource, RateLimiterProperties.Policy policy) {
        String key = RATE_LIMIT_PREFIX + clientId + ":" + resource;
        DefaultRedisScript<List> script = new DefaultRedisScript<>(TOKEN_BUCKET_SCRIPT, List.class);

        @SuppressWarnings("unchecked")
        List<Long> result = redisTemplate.execute(
                script,
                List.of(key + ":tokens", key + ":timestamp"),
                String.valueOf(policy.getCapacity()),
                String.valueOf(policy.getRefillTokens()),
                String.valueOf(policy.getRefillPeriod().toMillis()),
                "1",
                String.valueOf(clock.millis()));

        if (result == null || result.size() < 3) {
            return RateLimitDecision.denied("RATE_LIMITER_UNAVAILABLE", 1);
        }

        boolean allowed = result.get(0) == 1;
        long remainingTokens = result.get(1);
        long retryAfter = result.get(2);

        if (allowed) {
            return RateLimitDecision.allowed(remainingTokens);
        }
        return RateLimitDecision.denied("RATE_LIMIT_EXCEEDED", retryAfter);
    }
}
