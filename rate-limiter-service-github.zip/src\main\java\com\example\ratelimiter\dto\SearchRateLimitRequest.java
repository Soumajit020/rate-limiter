package com.example.ratelimiter.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record SearchRateLimitRequest(
        @NotBlank
        @Size(max = 512)
        String query,

        @Size(max = 128)
        String userId
) {
}
