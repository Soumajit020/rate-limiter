package com.example.ratelimiter.dto;

public record RateLimitDecision(
        boolean allowed,
        String reason,
        long remainingTokens,
        long retryAfterSeconds
) {

    /**
     * Creates a successful rate-limit decision with the tokens left in the bucket.
     */
    public static RateLimitDecision allowed(long remainingTokens) {
        return new RateLimitDecision(true, "ALLOWED", remainingTokens, 0);
    }

    /**
     * Creates a denied rate-limit decision with a reason and retry delay.
     */
    public static RateLimitDecision denied(String reason, long retryAfterSeconds) {
        return new RateLimitDecision(false, reason, 0, retryAfterSeconds);
    }
}
