package com.example.ratelimiter.config;

import jakarta.validation.constraints.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.time.Duration;

@Validated
@ConfigurationProperties(prefix = "search.cache")
public class SearchCacheProperties {

    @NotNull
    private Duration ttl = Duration.ofMinutes(10);

    /**
     * Returns how long search results should stay in Redis cache.
     */
    public Duration getTtl() {
        return ttl;
    }

    /**
     * Sets how long search results should stay in Redis cache.
     */
    public void setTtl(Duration ttl) {
        this.ttl = ttl;
    }
}
