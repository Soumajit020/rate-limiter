package com.example.ratelimiter.api;

import com.example.ratelimiter.dto.SearchRateLimitRequest;
import com.example.ratelimiter.dto.SearchResponse;
import com.example.ratelimiter.security.ClientPrincipal;
import com.example.ratelimiter.service.RateLimiterService;
import com.example.ratelimiter.service.SearchService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/search")
public class SearchController {

    private final RateLimiterService rateLimiterService;
    private final SearchService searchService;

    /**
     * Wires rate limiting and search lookup services into this API controller.
     */
    public SearchController(RateLimiterService rateLimiterService, SearchService searchService) {
        this.rateLimiterService = rateLimiterService;
        this.searchService = searchService;
    }

    /**
     * Executes an authorized search after rate limiting, using Redis first and MySQL on cache miss.
     */
    @PostMapping
    @PreAuthorize("hasRole('SEARCH')")
    public ResponseEntity<?> search(
            @AuthenticationPrincipal ClientPrincipal principal,
            @Valid @RequestBody SearchRateLimitRequest request) {
        String resource = request.userId() == null || request.userId().isBlank()
                ? "search:anonymous"
                : "search:user:" + request.userId();

        var decision = rateLimiterService.consume(principal.clientId(), resource, principal.policy());
        if (!decision.allowed()) {
            return ResponseEntity.status(429)
                    .header("Retry-After", String.valueOf(decision.retryAfterSeconds()))
                    .body(decision);
        }

        SearchResponse response = searchService.search(request.query());
        if (!response.found()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(response);
    }
}
