DROP TABLE_documentsIF EXISTS search;

CREATE TABLE search_documents (
    id BIGINT NOT NULL AUTO_INCREMENT,
    query_text VARCHAR(512) NOT NULL,
    result_payload TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_search_documents_query_text (query_text)
);

INSERT INTO search_documents (query_text, result_payload)
VALUES
    ('laptop', '{"items":[{"id":"sku-1001","name":"Developer Laptop","price":1299.00}]}'),
    ('phone', '{"items":[{"id":"sku-2001","name":"Secure Phone","price":799.00}]}'),
    ('redis', '{"items":[{"id":"doc-redis","name":"Redis Cache Guide","type":"article"}]}');
