$ErrorActionPreference = "Stop"

$mysqlUser = if ($env:MYSQL_USERNAME) { $env:MYSQL_USERNAME } else { "rate_limiter" }
$mysqlPassword = if ($env:MYSQL_PASSWORD) { $env:MYSQL_PASSWORD } else { throw "Set MYSQL_PASSWORD before running this script." }

mvn flyway:repair `
  "-Dflyway.url=jdbc:mysql://localhost:3306/rate_limiter_db" `
  "-Dflyway.user=$mysqlUser" `
  "-Dflyway.password=$mysqlPassword"
