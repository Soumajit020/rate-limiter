package com.example.ratelimiter;

import com.example.ratelimiter.config.RateLimiterProperties;
import com.example.ratelimiter.config.SearchCacheProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties({RateLimiterProperties.class, SearchCacheProperties.class})
public class RateLimiterServiceApplication {

    /**
     * Starts the Spring Boot application and loads the configured services.
     */
    public static void main(String[] args) {
        SpringApplication.run(RateLimiterServiceApplication.class, args);
    }
}
