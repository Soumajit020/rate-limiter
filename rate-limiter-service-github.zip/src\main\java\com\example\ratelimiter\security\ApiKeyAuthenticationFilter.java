package com.example.ratelimiter.security;

import com.example.ratelimiter.service.FraudAbuseService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class ApiKeyAuthenticationFilter extends OncePerRequestFilter {

    public static final String CLIENT_ID_HEADER = "X-Client-Id";
    public static final String API_KEY_HEADER = "X-Api-Key";

    private final AuthorizationService authorizationService;
    private final FraudAbuseService fraudAbuseService;

    /**
     * Wires credential validation and abuse inspection into the request filter.
     */
    public ApiKeyAuthenticationFilter(AuthorizationService authorizationService, FraudAbuseService fraudAbuseService) {
        this.authorizationService = authorizationService;
        this.fraudAbuseService = fraudAbuseService;
    }

    /**
     * Skips API-key validation for actuator endpoints that are intentionally public.
     */
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        return request.getRequestURI().startsWith("/actuator/");
    }

    /**
     * Authenticates API-key requests, blocks abusive traffic, and stores the client in the security context.
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String clientId = request.getHeader(CLIENT_ID_HEADER);
        String apiKey = request.getHeader(API_KEY_HEADER);

        var principal = authorizationService.authenticate(clientId, apiKey);
        if (principal.isEmpty()) {
            fraudAbuseService.recordFailedAuthorization(clientId, clientIp(request));
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid API credentials");
            return;
        }

        var abuseDecision = fraudAbuseService.inspectRequest(principal.get(), request);
        if (!abuseDecision.allowed()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, abuseDecision.reason());
            return;
        }

        var authentication = new ClientAuthentication(principal.get());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        filterChain.doFilter(request, response);
    }

    /**
     * Resolves the caller IP, preferring X-Forwarded-For when the service is behind a proxy.
     */
    private String clientIp(HttpServletRequest request) {
        String forwardedFor = request.getHeader("X-Forwarded-For");
        if (forwardedFor != null && !forwardedFor.isBlank()) {
            return forwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }

    private static class ClientAuthentication extends AbstractAuthenticationToken {
        private final ClientPrincipal principal;

        /**
         * Converts client roles into Spring Security authorities.
         */
        ClientAuthentication(ClientPrincipal principal) {
            super(principal.roles().stream()
                    .map(role -> role.startsWith("ROLE_") ? role : "ROLE_" + role)
                    .map(SimpleGrantedAuthority::new)
                    .toList());
            this.principal = principal;
            setAuthenticated(true);
        }

        /**
         * Returns empty credentials because the raw API key is not kept after authentication.
         */
        @Override
        public Object getCredentials() {
            return "";
        }

        /**
         * Returns the authenticated client details for controller and service access.
         */
        @Override
        public ClientPrincipal getPrincipal() {
            return principal;
        }
    }
}
