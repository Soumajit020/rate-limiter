package com.example.ratelimiter.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "search_documents")
public class SearchDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "query_text", nullable = false, unique = true, length = 512)
    private String queryText;

    @Column(name = "result_payload", nullable = false, columnDefinition = "TEXT")
    private String resultPayload;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    /**
     * Returns the database-generated primary key.
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the database-generated primary key.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Returns the search query text stored in MySQL.
     */
    public String getQueryText() {
        return queryText;
    }

    /**
     * Sets the search query text stored in MySQL.
     */
    public void setQueryText(String queryText) {
        this.queryText = queryText;
    }

    /**
     * Returns the search result payload stored for this query.
     */
    public String getResultPayload() {
        return resultPayload;
    }

    /**
     * Sets the search result payload stored for this query.
     */
    public void setResultPayload(String resultPayload) {
        this.resultPayload = resultPayload;
    }

    /**
     * Returns when this search document was created.
     */
    public Instant getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets when this search document was created.
     */
    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Returns when this search document was last updated.
     */
    public Instant getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Sets when this search document was last updated.
     */
    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }
}
