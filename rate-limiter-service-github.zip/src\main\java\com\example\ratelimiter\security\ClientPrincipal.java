package com.example.ratelimiter.security;

import com.example.ratelimiter.config.RateLimiterProperties;

import java.util.List;

public record ClientPrincipal(
        String clientId,
        List<String> roles,
        RateLimiterProperties.Policy policy
) {
}
