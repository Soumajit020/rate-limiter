# Rate Limiter Search Service

Spring Boot microservice for Redis-backed rate limiting, API-key authorization, fraud/abuse controls, and Redis-first search lookup with MySQL fallback.

## Features

- Redis token-bucket limiter with atomic Lua execution
- Per-client plan limits and role-based endpoint access
- Abuse checks for blocked clients, blocked IPs, suspicious user agents, high-risk headers, and repeated failures
- Search guard endpoint that returns allow/deny decisions without executing the search itself
- Search endpoint that checks Redis cache first, falls back to MySQL on cache miss, then populates Redis
- Flyway migration for MySQL schema and seed data
- Actuator health endpoint and Docker Compose Redis

## Project Structure

```text
src/main/java/com/example/ratelimiter
  api/          REST controllers
  config/       Spring Boot configuration properties and security config
  dto/          Request and response objects
  entity/       JPA entities mapped to MySQL tables
  repository/   Spring Data repositories
  security/     API-key authentication and authenticated client principal
  service/      Business logic for rate limiting, search, cache, and abuse checks
```

## Run

```powershell
docker compose up -d redis mysql
mvn spring-boot:run
```

If you prefer not to use `docker-compose.yml`, run the equivalent PowerShell script:

```powershell
.\scripts\start-infra.ps1
mvn spring-boot:run
```

Stop the containers:

```powershell
.\scripts\stop-infra.ps1
```

## Flyway Migration Error

If you see a checksum mismatch like this:

```text
Migration checksum mismatch for migration version 1
```

It means Flyway already ran `V1__create_search_documents.sql`, but that migration file changed afterward. For local development, use one of these fixes.

Repair Flyway history when the database schema is already correct:

```powershell
.\scripts\repair-flyway.ps1
```

Reset the local MySQL database and let Flyway recreate it from scratch:

```powershell
.\scripts\reset-local-db.ps1
mvn spring-boot:run
```

The service starts on `http://localhost:8080`.

## Example

```powershell
$headers = @{
  "X-Api-Key" = $env:DEMO_SEARCH_API_KEY
  "X-Client-Id" = "demo-search"
  "X-Forwarded-For" = "203.0.113.10"
}

Invoke-RestMethod -Method Post `
  -Uri "http://localhost:8080/api/v1/rate-limit/search/check" `
  -Headers $headers `
  -ContentType "application/json" `
  -Body '{"query":"laptop","userId":"user-123"}'
```

Run the actual Redis-first search flow:

```powershell
Invoke-RestMethod -Method Post `
  -Uri "http://localhost:8080/api/v1/search" `
  -Headers $headers `
  -ContentType "application/json" `
  -Body '{"query":"laptop","userId":"user-123"}'
```

The response includes `source`:

- `CACHE`: found in Redis
- `MYSQL`: missed Redis, found in MySQL, then cached in Redis
- `MISS`: not found in either store

## Important Headers

- `X-Api-Key`: required API key
- `X-Client-Id`: client identifier; must match the API key owner
- `X-Forwarded-For`: used for IP-oriented abuse controls when present
- `X-Risk-Score`: optional upstream risk score from `0` to `100`

## Configuration

Edit `src/main/resources/application.properties` for shared non-secret settings. Put local passwords and API keys in `application-local.properties`, which is ignored by Git.

Create your local file from the example:

```powershell
Copy-Item application-local.example.properties application-local.properties
```

Then update `application-local.properties` with your machine's values.

Redis connection:

```properties
spring.data.redis.host=localhost
spring.data.redis.port=6379
```

MySQL connection:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/rate_limiter_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=${MYSQL_USERNAME:}
spring.datasource.password=${MYSQL_PASSWORD:}
```

API keys are also read from local properties or environment variables:

```properties
rate-limiter.clients.demo-search.api-key=${DEMO_SEARCH_API_KEY:}
rate-limiter.clients.trusted-partner.api-key=${TRUSTED_PARTNER_API_KEY:}
```

## MySQL SQL

The SQL that runs in MySQL is managed by Flyway:

```text
src/main/resources/db/migration/V1__create_search_documents.sql
```

Flyway runs this migration automatically when the app starts.

Never commit real API keys, cloud Redis passwords, or database passwords. Keep those values in `application-local.properties` or `.env`.
