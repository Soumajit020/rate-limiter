package com.example.ratelimiter.service;

import com.example.ratelimiter.dto.SearchResponse;
import com.example.ratelimiter.repository.SearchDocumentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SearchService {

    private final SearchCacheService searchCacheService;
    private final SearchDocumentRepository searchDocumentRepository;

    /**
     * Wires the Redis cache service and MySQL repository used by the search flow.
     */
    public SearchService(SearchCacheService searchCacheService, SearchDocumentRepository searchDocumentRepository) {
        this.searchCacheService = searchCacheService;
        this.searchDocumentRepository = searchDocumentRepository;
    }

    /**
     * Searches Redis first, then falls back to MySQL when the query is not cached.
     */
    @Transactional(readOnly = true)
    public SearchResponse search(String query) {
        String normalizedQuery = query.trim();

        return searchCacheService.get(normalizedQuery)
                .map(cached -> new SearchResponse(true, normalizedQuery, cached.result(), "CACHE"))
                .orElseGet(() -> searchMysqlAndPopulateCache(normalizedQuery));
    }

    /**
     * Looks up a query in MySQL and writes successful results back into Redis.
     */
    private SearchResponse searchMysqlAndPopulateCache(String query) {
        return searchDocumentRepository.findFirstByQueryTextIgnoreCase(query)
                .map(document -> {
                    SearchResponse response = new SearchResponse(true, query, document.getResultPayload(), "MYSQL");
                    searchCacheService.put(query, response);
                    return response;
                })
                .orElseGet(() -> SearchResponse.miss(query));
    }
}
